
  # Parking Management Web App

  This is a code bundle for Parking Management Web App. The original project is available at https://www.figma.com/design/PZt9AcQMDk9qyDYZwaAqL1/Parking-Management-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  